<?php  
include "convert.php";
?>
 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
 
<head>
    <title>Cryptography</title>
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="generator" content="Geany 0.18" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans+Condensed:wght@300&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Staatliches&display=swap" rel="stylesheet">
<style type="text/css">
body{
    background-image: url(Image/slide103.jpeg);
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-size: cover;
    background-position: center;
}
.title h2 {
    text-align: center;
    font-family: 'Bebas Neue', cursive;
    margin-top: 40px;
    margin-left: 30%;
    margin-right: 30%;
    word-spacing: 5px;
    letter-spacing: 5px;
    font-size: 23px;
    margin-bottom: 40px;
    padding: 10px;

}
.table {
    width: auto;
    border-radius: 10px;
    margin-left: 25%;
    margin-right: 20%;
    margin-bottom: 10px;
}
input[type=text] {
   border-radius: 10px;
   height: 30px;
   width: 70px;
   margin-bottom: 20px;
}


input[type=submit] {
    background-color: #03506F;
    color: white;
    margin: 15px;
    cursor: pointer;
    border-radius: 5px;
}

input[type=submit]:hover {
    background-color: black;
}

fieldset {
border: 2px solid black;
margin: 20px;
}
fieldset legend {
    font-family: 'Open Sans Condensed', sans-serif;
    font-size: 20px;
}

input[type=reset] {
    background-color: #03506F;
    color: white;
    margin-left: 20px;
    cursor: pointer;
    border-radius: 5px;
}

input[type=reset]:hover {
    background-color: black;
}

    
    </style>
    <script type="text/javascript">
        function SelectAll(id) {
            document.getElementById(id).focus();
            document.getElementById(id).select();
        }

        function InfoCaesar() {
            alert("Key hanya berupa kombinasi angka," + '\n' + "dan plan text tidak boleh mengandung angka!");
        }
    </script>
</head>
 
<body>
    <div class="title">
        <h2>Cryptography with caesar's algorithm</h2>
    </div>

    <div class="table">
        <table>
            <tr>
                <td width="50%" valign="top">
                    <fieldset>
                        <legend><b>Caesar</b></legend>
                        <form action="index.php" method="post">
                            <input type="text" name="key_caesar" id="key_caesar" value="the key..." onclick="SelectAll('key_caesar')" />
                            <input type="submit" value="?" onclick="InfoCaesar()" /><br/>
                            <textarea rows="4" name="plantext_caesar" id="plantext_caesar" cols="33" onclick="SelectAll('plantext_caesar')">plain text...</textarea><br/>
                            <input type="submit" name="encrypt_caesar" value="Encrypt" /><input type="submit" name="decrypt_caesar" value="Decrypt" /><input type="reset" value="Reset" />
                        </form>
                    </fieldset>
                </td>
                <td colspan="5">
                    <fieldset>
                        <legend><b>Result</b></legend>
    <?php
    //----------------------------------------------------------------//
    // caesar                                                         //
    //----------------------------------------------------------------//
        if((isset($_POST['key_caesar'])) && (isset($_POST['plantext_caesar'])) && isset($_POST['encrypt_caesar'])){
            $key=$_POST['key_caesar'];
            $plantext=$_POST['plantext_caesar'];
            $split_key=str_split($key);
            $i=0;
            $split_chr=str_split($plantext);
            while ($key>52){
                $key=$key-52;
            }
            foreach($split_chr as $chr){
                if (char_to_dec($chr)!=null){
                    $split_nmbr[$i]=char_to_dec($chr);
                } else {
                    $split_nmbr[$i]=$chr;
                }
                $i++;
            }
            echo '<textarea rows="4" id="result" cols="33" onclick="SelectAll(\'result\')" >';
            foreach($split_nmbr as $nmbr){
                if (((int)$nmbr+(int)$key)>52){
                    if (dec_to_char($nmbr)!=null){
                        echo dec_to_char(($nmbr+$key)-52);
                    } else {
                        echo $nmbr;
                    }
                } else {
                    if (dec_to_char($nmbr)!=null){
                        echo dec_to_char($nmbr+$key);
                    } else {
                        echo $nmbr;
                    }
                }
            }
            echo '</textarea><br/>';
        } else if ((isset($_POST['key_caesar'])) && (isset($_POST['plantext_caesar'])) && isset($_POST['decrypt_caesar'])){
            $key=$_POST['key_caesar'];
            $plantext=$_POST['plantext_caesar'];
            $i=0;
            $split_chr=str_split($plantext);
            while ($key>52){
                $key=$key-52;
            }
            foreach($split_chr as $chr){
                if (char_to_dec($chr)!=null){
                    $split_nmbr[$i]=char_to_dec($chr);
                } else {
                    $split_nmbr[$i]=$chr;
                }
                $i++;
            }
            echo '<textarea rows="4" id="result" cols="33" onclick="SelectAll(\'result\')" >';
            foreach($split_nmbr as $nmbr){
                if (((int)$nmbr-(int)$key)<1){
                    if (dec_to_char($nmbr)!=null){
                        echo dec_to_char(($nmbr-$key)+52);
                    } else {
                        echo $nmbr;
                    }
                } else {
                    if (dec_to_char($nmbr)!=null){
                        echo dec_to_char($nmbr-$key);
                    } else {
                        echo $nmbr;
                    }
                }
            }

        }else {
            echo '<textarea rows="4" id="result" cols="33" onclick="SelectAll(\'result\')">result here..';
        }
        ?>